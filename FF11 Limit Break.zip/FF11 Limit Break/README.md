# FF11 Limit Break



1. Keep the complete extracted folder together in a writable location.
2. Open FF11 Limit Break.exe and accept its Windows administrator prompt.
3. Select pol.exe and FINAL FANTASY XI. Add and name each Windower folder.
4. Select a folder and use Prepare addon. Back up the installed LimitBreak addon, then follow the separate exported READ-ME.txt. The UI does not overwrite your installed addon or init file.
5. Launch selected, choose the usual Windower profile, wait until the UI says Armed, then choose Play in POL.
6. After login check: \[FF11 Limit Break] 1024 MiB verified; XIPivot loading requested.



Multiple different folders may launch independently. No successful-ARMED OK dialog appears. An Armed status only confirms early arming; the in-game measurement confirms pool capacity. Manual //lbtest remains available.

On failure or cancellation, any newly opened unarmed POL client remains open. Do not choose Play in that client. Existing clients are not selected or closed.

Close this application and its launched clients before moving the application folder. Move data and compatibility with it. Game and Windower locations are remembered externally and can be changed through the UI. Keep the original absolute-path six-client build where it is.

Import update accepts signed .fflb packages trusted by this build. ABI2 checks known engine structures and derives current addresses; unverified layouts/interfaces and payload changes are refused. Windower/Hook versions are not pinned; LuaCore uses a cached functional bridge test. Check compatibility runs the all-folder check manually; the first launch each app session runs it automatically when needed. Roll back update selects the prior package; prepare/copy that package's addon to complete a rollback. It does not change your folder list.

The inherited adapter mutes the new client's default audio session. You can unmute it in Windows Mixer. It changes process memory before pool initialization; it does not edit game DLLs or DATs. Existing overlay and cache settings should remain as configured. This does not guarantee prevention of unrelated crashes.

